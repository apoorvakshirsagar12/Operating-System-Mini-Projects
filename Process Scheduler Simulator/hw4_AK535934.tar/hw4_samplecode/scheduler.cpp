#include "scheduler.h"
#include "queues.h"

bool cpuBusy = false;

int totalWait = 0;
int processesStarted = 0; //if a job is blocked, it counts twice.
int maxWait = 0;

int blocked_arrived=INT_MAX;

//Simply used for statistics reporting
double getAvgWait()
{
	return (double) totalWait / processesStarted;
}

//Routine triggered once per quantum (on simulated clock interrupt) to determine which
//process gets CPU time and maintains queues
int scheduler()
{
	int i;

	//cpu needs to be free to dispatch.....
	if(cpuBusy == false && readyq != NULL)
	{
		my_queue* head = popQ(&readyq, &ready_tail);

        	updateState(head);	//Process popped from readyQ sent for execution.
        	dispatch(&head);
	}
}

// This routine adds the specified task to the Processing queue.
// Maintaining FCFS philosophy, it is added to end
void dispatch(my_queue** t) 
{
	my_queue* task = *t;

	//update Statistics
	int waitTime = cpuTimer - (task->this_task.arrival_time);
	totalWait+=waitTime;
	processesStarted++;
	if (waitTime > maxWait)
		maxWait = waitTime;

	*t = task;
}

//This routine updates the process states in the PCB (Process Control Block)
//Queues are updated maintaining FCFS philosophy
void updateState(my_queue* task)
{
	cpuBusy = true;		//CPU acquired by Process hence Busy.

	if((task->this_task.time_run < (task->this_task.est_runtime-1)))
        {
        	task->this_task.state = 1;	//Status of the process marked as RUNNING.
        	cout << cpuTimer << " |RUNNING: " << task->this_task.taskid << " runtime: " << task->this_task.time_run << endl;

        	task->this_task.time_run++;
		task->this_task.state= 0;	//Status of the process marked as READY.

		//Execution of the processes with Block Time
      		if(task->this_task.time_run == task->this_task.block_startTime)
        	{
			processing_tail=task;
        		processing_tail->this_task.state = 3;	//Status of the process marked as BLOCKED.

        		cout << cpuTimer << " |BLOCK TASK: " << processing_tail->this_task.taskid << endl;
        		cout << " BLOCK WAIT TIME: " << processing_tail->this_task.block_waitTime << endl;

			processesStarted = processesStarted + 2;	//For the BLOCKED process, it is counted as twice

			blocked_arrived =  cpuTimer + processing_tail->this_task.block_waitTime;	//Arrival_time for BLOCKED process to enter the readyQ again.
        	}

        	if(task->this_task.state == 0)	//If the status is READY,then push the process in readyQ again.
        	{
        		pushQ(&readyq, &task, &ready_tail);
        	}

        	if(cpuTimer == blocked_arrived)	//When the block_waitTime for the BLOCKED process is over, add the process to jobQ again.
     		{
        		pushQ(&jobq, &processing_tail, &job_tail);
       		}
        }
        else if(task->this_task.time_run == (task->this_task.est_runtime-1))	//While the last second of process execution 
        {
		task->this_task.state = 1;
        	cout << cpuTimer << " |RUNNING: " << task->this_task.taskid << " runtime: " << task->this_task.time_run << endl;	//Process execution complete

		task->this_task.state = 5;	//Status of the process marked as TERMINATED
        	cout << cpuTimer << " |TERMINATED TASK: " << task->this_task.taskid << endl;	//Process terminated
        }
	cpuBusy =  false;	//CPU released by the process hence freed.
}

